import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-info',
  templateUrl: './travel-info.component.html',
  styleUrls: ['./travel-info.component.scss']
})
export class TravelInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
