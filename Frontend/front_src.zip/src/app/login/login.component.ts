import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router'; // For navigation
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../Services/auth.service';
 // For making HTTP requests

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string = ''; // To store error message

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private http: HttpClient,
    private authService: AuthService
  ) {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { email, password } = this.loginForm.value;
      const requestBody = { email, password };

      // Send login request to backend
      this.http.post('http://localhost:3000/api/auth/login', requestBody)
        .subscribe(
          (response: any) => {
              this.authService.login(email,password);
              console.log('Login successful:', response);
              this.router.navigate(['/home/home']); // Redirect to home page after successful login
            },
          error => {
            // Handle error
            if (error.error && error.error.message) {
              this.errorMessage = error.error.message; // Show error message to user
            }
          }
        );
    } else {
      console.log('Form is invalid');
    }
  }
}
