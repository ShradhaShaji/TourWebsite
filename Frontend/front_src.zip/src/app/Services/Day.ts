export class Day {
  title?: string;
  plan?: string;
}
