import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private isAuthenticated = false;
  constructor(private http: HttpClient) {}
  isLoggedIn(): boolean {
    const token = localStorage.getItem('auth_token');
    return !!token;
  }

  login(email: string, password: string) {
    this.isAuthenticated=(true);
    return this.http.post('/api/auth/login', { email, password });
  }
  logout(): void {
    this.isAuthenticated=(false); // Update login state to false
  }

  register(name: string, email: string, password: string) {
    return this.http.post('/api/auth/regiser', { name, email, password });
  }
}
