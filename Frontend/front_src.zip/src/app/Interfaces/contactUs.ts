export class ContactUs {
  name!: string;
  email!: string;
  messages!: string;
}
