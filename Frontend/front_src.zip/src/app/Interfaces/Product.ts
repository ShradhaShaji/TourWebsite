import {Subproduct} from "./Subproduct";
export class Product {
  image?: string;
  label?: string;
  packages?: Subproduct[];
}
