export interface Details {
  image?:string,
  explain?:string,
  url?:string,
  id?: string
}
