
export class Subproduct {
  id?:number;
  days?: string;
  description?: string;
  details?: any;
  image?: string;
  place?: string;
}
