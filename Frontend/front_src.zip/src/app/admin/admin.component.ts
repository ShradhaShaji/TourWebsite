import { Component } from '@angular/core';
import { AdminService } from '../Services/admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent {
  users: any[] = [];
  tours: any[] = [];
  selectedTab: string = 'users';

  constructor(private adminService: AdminService) {
    this.loadUsers();
    this.loadTours();
  }

  loadUsers() {
    this.adminService.getUsers().subscribe((data: any) => {
      this.users = data;
    });
  }

  loadTours() {
    this.adminService.getTours().subscribe((data: any) => {
      this.tours = data;
    });
  }
}
