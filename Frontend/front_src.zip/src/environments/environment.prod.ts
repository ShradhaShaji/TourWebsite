export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyA5eMPeY-Ef90xVn6q6nRXUZwIXNtjTjso",
    authDomain: "e-commerce-31737.firebaseapp.com",
    databaseURL: "https://e-commerce-31737-default-rtdb.firebaseio.com",
    projectId: "e-commerce-31737",
    storageBucket: "e-commerce-31737.appspot.com",
    messagingSenderId: "433468818907",
    appId: "1:433468818907:web:a22f212ee6f4438ecb93fe",
    recaptcha: {
      siteKey: '6LcDtH0nAAAAAIRxtkts9AiltgsmHxhfVAcQz4MU',
    },
  },
};
